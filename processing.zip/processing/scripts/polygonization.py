"""
Model exported as python.
Name : Polygonization
Group : AI as a Service
With QGIS : 31603
"""

from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterRasterLayer
from qgis.core import QgsProcessingParameterNumber
from qgis.core import QgsProcessingParameterFeatureSink
from qgis.core import QgsExpression
import processing


class Polygonization(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer('Infe', 'Infe', defaultValue=None))
        self.addParameter(QgsProcessingParameterNumber('Resampling00none', 'Resampling (0 is none)', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=1.79769e+308, defaultValue=0))
        self.addParameter(QgsProcessingParameterFeatureSink('HydroOutput', 'Hydro output', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('Vegetation_output', 'Vegetation_output', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('RoadOutput', 'Road output', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))
        self.addParameter(QgsProcessingParameterFeatureSink('BuildingOutput', 'Building output', type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, supportsAppend=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(17, model_feedback)
        results = {}
        outputs = {}

        # r.to.vect
        alg_params = {
            '-b': False,
            '-s': True,
            '-t': False,
            '-v': False,
            '-z': False,
            'GRASS_OUTPUT_TYPE_PARAMETER': 0,
            'GRASS_REGION_CELLSIZE_PARAMETER': QgsExpression(' @Resampling00none ').evaluate(),
            'GRASS_REGION_PARAMETER': None,
            'GRASS_VECTOR_DSCO': '',
            'GRASS_VECTOR_EXPORT_NOCAT': False,
            'GRASS_VECTOR_LCO': '',
            'column': 'value',
            'input': parameters['Infe'],
            'type': 2,
            'output': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Rtovect'] = processing.run('grass7:r.to.vect', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        #  Extract by attribute Hyd
        alg_params = {
            'FIELD': 'value',
            'INPUT': outputs['Rtovect']['output'],
            'OPERATOR': 0,
            'OUTPUT': 'TEMPORARY_OUTPUT',
            'VALUE': '2',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtractByAttributeHyd'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Extract by attribute Veg
        alg_params = {
            'FIELD': 'value',
            'INPUT': outputs['Rtovect']['output'],
            'OPERATOR': 0,
            'OUTPUT': 'TEMPORARY_OUTPUT',
            'VALUE': '1',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtractByAttributeVeg'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Extract by attribute Bui
        alg_params = {
            'FIELD': 'value',
            'INPUT': outputs['Rtovect']['output'],
            'OPERATOR': 0,
            'OUTPUT': 'TEMPORARY_OUTPUT',
            'VALUE': '4',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtractByAttributeBui'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Veg Multipart to singleparts
        alg_params = {
            'INPUT': outputs['ExtractByAttributeVeg']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['VegMultipartToSingleparts'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Extract by attribute Roa
        alg_params = {
            'FIELD': 'value',
            'INPUT': outputs['Rtovect']['output'],
            'OPERATOR': 0,
            'OUTPUT': 'TEMPORARY_OUTPUT',
            'VALUE': '3',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['ExtractByAttributeRoa'] = processing.run('native:extractbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Hydro Multipart to singleparts
        alg_params = {
            'INPUT': outputs['ExtractByAttributeHyd']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['HydroMultipartToSingleparts'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Build Multipart to singleparts
        alg_params = {
            'INPUT': outputs['ExtractByAttributeBui']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BuildMultipartToSingleparts'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # Road Multipart to singleparts
        alg_params = {
            'INPUT': outputs['ExtractByAttributeRoa']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RoadMultipartToSingleparts'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # Fix geometries Hyd
        alg_params = {
            'INPUT': outputs['HydroMultipartToSingleparts']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FixGeometriesHyd'] = processing.run('native:fixgeometries', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # Fix geometries Veg
        alg_params = {
            'INPUT': outputs['VegMultipartToSingleparts']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FixGeometriesVeg'] = processing.run('native:fixgeometries', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # Fix geometries Roa
        alg_params = {
            'INPUT': outputs['RoadMultipartToSingleparts']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FixGeometriesRoa'] = processing.run('native:fixgeometries', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(12)
        if feedback.isCanceled():
            return {}

        # Veg Multipart to singleparts
        alg_params = {
            'INPUT': outputs['FixGeometriesVeg']['OUTPUT'],
            'OUTPUT': parameters['Vegetation_output']
        }
        outputs['VegMultipartToSingleparts'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Vegetation_output'] = outputs['VegMultipartToSingleparts']['OUTPUT']

        feedback.setCurrentStep(13)
        if feedback.isCanceled():
            return {}

        # Fix geometries Bui
        alg_params = {
            'INPUT': outputs['BuildMultipartToSingleparts']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['FixGeometriesBui'] = processing.run('native:fixgeometries', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(14)
        if feedback.isCanceled():
            return {}

        # Hydro Multipart to singleparts
        alg_params = {
            'INPUT': outputs['FixGeometriesHyd']['OUTPUT'],
            'OUTPUT': parameters['HydroOutput']
        }
        outputs['HydroMultipartToSingleparts'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['HydroOutput'] = outputs['HydroMultipartToSingleparts']['OUTPUT']

        feedback.setCurrentStep(15)
        if feedback.isCanceled():
            return {}

        # Road Multipart to singleparts
        alg_params = {
            'INPUT': outputs['FixGeometriesRoa']['OUTPUT'],
            'OUTPUT': parameters['RoadOutput']
        }
        outputs['RoadMultipartToSingleparts'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['RoadOutput'] = outputs['RoadMultipartToSingleparts']['OUTPUT']

        feedback.setCurrentStep(16)
        if feedback.isCanceled():
            return {}

        # Multipart to singleparts
        alg_params = {
            'INPUT': outputs['FixGeometriesBui']['OUTPUT'],
            'OUTPUT': parameters['BuildingOutput']
        }
        outputs['MultipartToSingleparts'] = processing.run('native:multiparttosingleparts', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['BuildingOutput'] = outputs['MultipartToSingleparts']['OUTPUT']
        return results

    def name(self):
        return 'Polygonization'

    def displayName(self):
        return 'Polygonization'

    def group(self):
        return 'AI as a Service'

    def groupId(self):
        return 'AI as a Service'

    def shortHelpString(self):
        return """<html><body><h2>Algorithm description</h2>
<p>Polygonization of the raster file</p>
<h2>Input parameters</h2>
<h3>Infe</h3>
<p>Input GeoTIFF raster file</p>
<h3>Resampling (0 is none)</h3>
<p>The polygonizer can resample the input raster file. This resampling (generalization) is interesting as it improves the performance of the polygonization and reduce the size of the output file. If the value is 0 no resampling is done.</p>
<h3>Hydro output</h3>
<p>Hydrography layer</p>
<h3>Vegetation_output</h3>
<p>Vegetation layer</p>
<h3>Road output</h3>
<p>Road layer</p>
<h3>Building output</h3>
<p>Building layer</p>
<h2>Outputs</h2>
<h3>Hydro output</h3>
<p>Hydrography layer</p>
<h3>Vegetation_output</h3>
<p>Vegetation layer</p>
<h3>Road output</h3>
<p>Road layer</p>
<h3>Building output</h3>
<p>Building layer</p>
<br><p align="right">Algorithm version: 1.0</p></body></html>"""

    def createInstance(self):
        return Polygonization()
